import React from 'react';

const NoMatch = () => {
    return (
        <div className="text-center text-danger">
            <h1>Not Found</h1>
        </div>
    );
};

export default NoMatch;