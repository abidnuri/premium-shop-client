const FakeData = 
[{
    "id": 1,
    "name": "Rice",
    "quantity": "2",
    "img":"https://i.ibb.co/G9vb5DC/image-35.png",
    "price": "$1500"
  },
{
    "id": 2,
    "name": "Chanachur",
    "quantity": "4",
    "img":"https://i.ibb.co/G9vb5DC/image-35.png",
    "price": "$1600"
  },
{
    "id": 3,
    "name": "Coil",
    "quantity": "1",
    "img":"https://i.ibb.co/G9vb5DC/image-35.png",
    "price": "$1800"
  },
{
    "id": 4,
    "name": "Potato",
    "quantity": "1",
    "img":"https://i.ibb.co/G9vb5DC/image-35.png",
    "price": "$1750"
  }	
  ]
  export default FakeData;