import React from 'react';

const Deals = () => {
    return (
        <div>
            <h2>This is Deals</h2>
        </div>
    );
};

export default Deals;