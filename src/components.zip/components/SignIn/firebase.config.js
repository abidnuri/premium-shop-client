const firebaseConfig = {
    apiKey: "AIzaSyDVOmFtzlqEXM6jYckfWwSysgyqGz6QZ1A",
    authDomain: "premium-shop-343a5.firebaseapp.com",
    projectId: "premium-shop-343a5",
    storageBucket: "premium-shop-343a5.appspot.com",
    messagingSenderId: "985788285184",
    appId: "1:985788285184:web:83fa87e20235d8e86cf3e5"
  };
  export default firebaseConfig;