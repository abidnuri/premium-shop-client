import React from 'react';

const Orders = () => {
    return (
        <div>
            <h2>This is Orders</h2>
        </div>
    );
};

export default Orders;